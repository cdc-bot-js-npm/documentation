---
description: >-
  The typical default command that is used for message commands to run commands
  based on a command message inclusing bot's prefix at beginning.
---

# prefixedCommand

