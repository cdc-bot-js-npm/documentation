---
description: A command that gets executed whenever a member is unbanned from a server.
---

# guildBanRemoveCommand

