---
description: >-
  A command that is triggered whenever the given name is typed in a channel.
  It's a messag based command that is triggered without prefix.
---

# nonPrefixedCommand

