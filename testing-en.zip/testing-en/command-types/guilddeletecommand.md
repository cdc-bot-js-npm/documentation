---
description: >-
  A command that gets executed whenever a server kicks the bot or the server is
  deleted/left.
---

# guildDeleteCommand

