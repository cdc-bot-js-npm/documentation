---
description: A command that gets executed whenever the bot joins a new server.
---

# guildCreateCommand

