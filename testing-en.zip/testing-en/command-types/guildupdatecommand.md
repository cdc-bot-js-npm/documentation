---
description: A command that gets executed whenever a guild is updated - e.g. name change.
---

# guildUpdateCommand

