---
description: >-
  A command that gets executed whenever a guild member updates - i.e. roles
  added/ removed, nickname changed etc. Also executes when the user's details
  (e.g. username) change.
---

# guildMemberUpdateCommand

