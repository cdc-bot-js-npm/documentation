---
description: A command that gets executed when the bot is back online after a restart.
---

# readyCommand

