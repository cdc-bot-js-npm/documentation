---
description: >-
  A command that is triggered with every message in any text channel. This
  command is not based on a command name.
---

# messageCommand

