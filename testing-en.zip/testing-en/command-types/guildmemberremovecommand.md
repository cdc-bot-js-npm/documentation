---
description: 'A command that gets executed whenever a member leaves a guild, or is kicked.'
---

# guildMemberRemoveCommand

