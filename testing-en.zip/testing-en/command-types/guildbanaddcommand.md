---
description: A command that gets executed whenever a member is banned from a server.
---

# guildBanAddCommand

