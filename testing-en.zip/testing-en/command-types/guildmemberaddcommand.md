---
description: A command that gets executed when a new user joins a server.
---

# guildMemberAddCommand

