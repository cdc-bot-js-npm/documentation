---
description: >-
  Here you can find all available client events cdc-bot.js offers you to code
  your bots.
---

# Client Events

