---
description: >-
  cdc-bot.js is a small npm package to let you code easily your own Discord Bots
  within a few weeks. Much capacy, less knowlegde needed. With our package it's
  possible to code your great Discord bots.
---

# About cdc-bot.js

Welcome to the official website of cdc-bot.js!

{% hint style="success" %}
Join our community & support server: [discord.gg/bot-coding](https://discord.gg/bot-coding)
{% endhint %}

![](.gitbook/assets/banner-cdc2.png)

