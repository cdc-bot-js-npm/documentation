---
description: >-
  A compact function with multiple options to return data about the given custom
  emoji.
---

# $emoji

