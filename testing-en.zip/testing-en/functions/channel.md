---
description: >-
  A compact function with multiple options to return data about the given
  channel.
---

# $channel

### Description

This function is used to get several information about the given channel.  
If you don't provide any data in the function, it will return the current channel's ID.

### Usage

Raw usage: `$channel[option (optional);channelID (optional)]`

This function has two optional fields:

1. `option` =&gt; the option you want to get of the channel.
2. `channelID` =&gt; the ID of the channel you want to get the date of, default is the current channel's ID.

#### Options:

| Option | Description |
| :--- | :--- |
|  |  |

### Example Commands



