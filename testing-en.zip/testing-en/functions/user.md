---
description: A compact function with multiple options to return data about the given user.
---

# $user

