---
description: >-
  Our cdc-bot.js Tools-Bot has everything you need to develop your own bots with
  our package.
---

# The Tools-Bot

### What is the cdc-bot.js Tools-Bot?

Our cdc-bot.js Tools-Bot is a Discord Bot with many useful tools for you that helps you to code your Discord Bots with cdc-bot.js easily. It includes all our documentations, explainations and mayn other amazing developer tools.

### Features of the bot:

* **cdc-bot.js functions documentation:** Check information about our package's functions including function name, function's description, function's usage, details about the function and the url to the documentation page of the function.
* **cdc-bot.js client events list:** Check out what client events you can use for your bots. Check out [Client Events](../guides/client-events.md) for more information.
* 
{% hint style="success" %}
 **Invite the bot to your Discord server:** [Click here!](https://discord.com/api/oauth2/authorize?client_id=799747541926281237&permissions=388161&scope=bot%20applications.commands)
{% endhint %}



